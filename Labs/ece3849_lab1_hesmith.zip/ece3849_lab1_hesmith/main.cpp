#include <stdint.h>
#include <stdio.h>
#include <stdbool.h>

extern "C" {
#include "driverlib/fpu.h"
#include "driverlib/interrupt.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/pwm.h"
#include "driverlib/pin_map.h"
#include "inc/hw_memmap.h"
#include "inc/hw_ints.h"
#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"
#include "Crystalfontz128x128_ST7735.h"
}

#include "button.h"
#include "pins.h"
#include "joystick.h"
#include "OPT3001.h"

//unused libraries for this program
//#include "elapsedTime.h"
//#include "timerLib.h"

//---------------------------------------------------------------------------

//Two LED blink test code.

/*void blinkLEDOne(void *pvParameters) {
    for(;;){
        GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_0, GPIO_PIN_0); // LED ON
        vTaskDelay(pdMS_TO_TICKS(2000));
        GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_0, 0);          // LED OFF
        vTaskDelay(pdMS_TO_TICKS(2000));
    }
}

void blinkLEDTwo(void *pvParameters) {
    for(;;){
        GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_1, GPIO_PIN_1); // LED ON
        vTaskDelay(pdMS_TO_TICKS(200));
        GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_1, 0);          // LED OFF
        vTaskDelay(pdMS_TO_TICKS(200));
    }
}

int main(void) {
    IntMasterDisable();
    FPUEnable();
    FPULazyStackingEnable();

    SysCtlClockFreqSet(
        SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN |
        SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480,
        120000000
    );

    // Enable GPIO Port N and configure PN1 (LED D1) as output
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPION);
    while (!SysCtlPeripheralReady(SYSCTL_PERIPH_GPION)) {}
    GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_0);
    GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_1);

    IntMasterEnable();

    // Create a single task � just enough to prove the scheduler works
    xTaskCreate(blinkLEDOne, "LED1", 128, NULL, 1, NULL);
    xTaskCreate(blinkLEDTwo, "LED2", 128, NULL, 1, NULL);

    // Start scheduler (never returns)
    vTaskStartScheduler();

    while (1);
}*/

//---------------------------------------------------------------------------

//used for setting up the buzzer
#define BUZZER_PWM_BASE    PWM0_BASE
#define BUZZER_GEN         PWM_GEN_0
#define BUZZER_OUTNUM      PWM_OUT_1
#define BUZZER_OUTBIT      PWM_OUT_1_BIT

volatile uint32_t gSysClk = 0;

//time variables
volatile bool gRunning = false;
volatile uint16_t g_ms  = 0;
volatile uint8_t  g_sec = 0;
volatile uint8_t  g_min = 0;
volatile uint8_t  g_hr  = 0;

//FreeRTOS task and Queue variables
TickType_t timeKeepLastWake = xTaskGetTickCount();
QueueHandle_t xBuzzerSamples;

//physical button definitions
static Button btnPlayPause(S1);     // S1 -> Play/Pause
static Button btnRestart(S2);       // S2 -> Restart

struct MyButton {
    int x, y, w, h;
    const char* label;
    bool pressed;
};

//software button definitions
static MyButton btnStart = {39, 60, 50, 28, "PLAY", false};
static MyButton btnReset = {39, 100, 50, 28, "Reset", false};

static void setupButtons();
static void setupBuzzer();
static void BuzzerBeepOn(uint32_t freq_hz);
static void BuzzerBeepOff();
static void initializeDisplay(tContext &context);
static void drawStopwatchScreen(tContext &context, bool running);
static void drawButton(tContext &context, const MyButton &btn);

//timing task: updates the timing variables and runs every 10ms
void timeKeeping(void *pvParameters){
    for(;;){
        if (gRunning){
            g_ms += 10;

            if (g_ms >= 1000){
                g_ms = 0;
                g_sec++;
                if (g_sec >= 60){
                    g_sec = 0;
                    g_min++;
                    if (g_min >= 60){
                        g_min = 0;
                        g_hr++;
                        if (g_hr > 99){
                            g_hr = 99;
                        }
                    }
                }
            }
        }
        vTaskDelayUntil(&timeKeepLastWake, pdMS_TO_TICKS(10));
    }
}

//button scanning task: scans the user buttons for presses. If pressed, sends Queue data to the buzzer, and either play/pause the timer, or resets the timer.
void buttonScanning(void *pvParameters){
    for (;;){
        static uint16_t playPauseBTNSound = 1000;
        static uint16_t ResetBTNSound = 500;

        btnPlayPause.tick();
        btnRestart.tick();

        if (btnPlayPause.wasPressed()){
            xQueueSend(xBuzzerSamples, &playPauseBTNSound, pdMS_TO_TICKS(5)); //play buzzer sound

            btnStart.pressed = true;
            gRunning = !gRunning; //pause/play timer
            btnStart.label = gRunning ? "PAUSE" : "PLAY";
        }
        if (btnPlayPause.wasReleased()){
            btnStart.pressed = false;
        }
        if (btnRestart.wasPressed()){
            xQueueSend(xBuzzerSamples, &ResetBTNSound, pdMS_TO_TICKS(5)); //play buzzer sound

            btnReset.pressed = true;

            //reset timing variables to 0
            g_ms  = 0;
            g_sec = 0;
            g_min = 0;
            g_hr  = 0;
        }
        if (btnRestart.wasReleased()){
            btnReset.pressed = false;
        }

        vTaskDelay(pdMS_TO_TICKS(20));
    }
}

//update display task: draws the display UI and time numbers in HH:MM:SS:MS format
void displayUpdating (void *pvParameters){
    for (;;){
        tContext sContext;
        initializeDisplay(sContext);

        for (;;){
            drawStopwatchScreen(sContext, gRunning);
            drawButton(sContext, btnStart);
            drawButton(sContext, btnReset);

            #ifdef GrFlush
                GrFlush(&sContext);
            #endif

            vTaskDelay(pdMS_TO_TICKS(50));
        }
    }
}

//buzzer task: operates only on receiving Queue data. Turns the buzzer on at the received tone for 50ms ,then off, and goes back to wait.
void buzzerBuzzing (void *pvParameters){
    for (;;){
        uint16_t tone;

        if (xQueueReceive(xBuzzerSamples, &tone, portMAX_DELAY) == pdTRUE){ //receives Queue data and assigns it to the 'tone' variable.
            BuzzerBeepOn(tone);

            vTaskDelay(pdMS_TO_TICKS(50));

            BuzzerBeepOff();
        }
    }
}

int main(void){
    IntMasterDisable(); //disable ISRs.

    FPUEnable();
    FPULazyStackingEnable();

    gSysClk = SysCtlClockFreqSet(SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN | SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480, 120000000);

    setupButtons();

    setupBuzzer();

    IntMasterEnable(); //enable ISRs.

    //create buzzer Queue
    xBuzzerSamples = xQueueCreate(16, sizeof(int16_t));

    if (xBuzzerSamples == NULL) while (1){}

    //Create the required system tasks
    xTaskCreate(buzzerBuzzing, "buzzer", 512, NULL, 1, NULL);
    xTaskCreate(displayUpdating, "displayUpdate", 512, NULL, 1, NULL);
    xTaskCreate(buttonScanning, "buttonScan", 512, NULL, 2, NULL);
    xTaskCreate(timeKeeping, "timeKeep", 512, NULL, 3, NULL);

    vTaskStartScheduler(); //start the FreeRTOS scheduler

    while (1);
}

static void setupButtons(){
    btnPlayPause.begin();
    btnPlayPause.setTickIntervalMs(20);
    btnPlayPause.setDebounceMs(30);

    btnRestart.begin();
    btnRestart.setTickIntervalMs(20);
    btnRestart.setDebounceMs(30);
}

static void setupBuzzer(){
    SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM0);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
    while (!SysCtlPeripheralReady(SYSCTL_PERIPH_PWM0));
    while (!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOF));

    GPIOPinConfigure(GPIO_PF1_M0PWM1);
    GPIOPinTypePWM(GPIO_PORTF_BASE, GPIO_PIN_1);
    PWMClockSet(PWM0_BASE, PWM_SYSCLK_DIV_64);
}

static void initializeDisplay(tContext &context){
    Crystalfontz128x128_Init();
    Crystalfontz128x128_SetOrientation(LCD_ORIENTATION_UP);
    GrContextInit(&context, &g_sCrystalfontz128x128);
    GrContextFontSet(&context, &g_sFontFixed6x8);

    tRectangle full = {0, 0, 127, 127};
    GrContextForegroundSet(&context, ClrBlack);
    GrRectFill(&context, &full);
}

static void drawStopwatchScreen(tContext &context, bool running){
    uint8_t hours = g_hr;
    uint8_t minutes = g_min;
    uint8_t seconds = g_sec;
    uint16_t milseconds = g_ms;

    char timeSTR[20];

    tRectangle rectFull = {0, 0, 127, 127};
    GrContextForegroundSet(&context, ClrBlack);
    GrRectFill(&context, &rectFull);

    GrContextForegroundSet(&context, ClrCyan);
    GrStringDrawCentered(&context, "STOPWATCH", -1, 64, 15, false);

    snprintf(timeSTR, sizeof(timeSTR), "%02u : %02u : %02u : %02u", hours, minutes, seconds, milseconds);

    if (running){
        GrContextForegroundSet(&context, ClrGreen);
        GrStringDrawCentered(&context, "Running", -1, 64, 35, false);

        GrContextForegroundSet(&context, ClrYellow);
        GrStringDrawCentered(&context, timeSTR, -1, 64, 50, false);
    }
    else{
        GrContextForegroundSet(&context, ClrRed);
        GrStringDrawCentered(&context, "Stopped", -1, 64, 35, false);

        GrContextForegroundSet(&context, ClrOlive);
        GrStringDrawCentered(&context, timeSTR, -1, 64, 50, false);
    }
}

static void drawButton(tContext &context, const MyButton &btn){
    uint16_t bgColor = btn.pressed ? ClrBlack : ClrGray;
    uint16_t textColor = btn.pressed ? ClrWhite : ClrBlack;

    tRectangle rect = {btn.x, btn.y, btn.x + btn.w - 1, btn.y + btn.h - 1};
    GrContextForegroundSet(&context, bgColor);
    GrRectFill(&context, &rect);

    GrContextForegroundSet(&context, ClrBlack);
    GrRectDraw(&context, &rect);

    GrContextForegroundSet(&context, textColor);
    GrStringDrawCentered(&context, btn.label, -1, btn.x + btn.w / 2, btn.y + btn.h / 2, false);
}

static void BuzzerBeepOn(uint32_t freq_hz){
    if (freq_hz == 0) return;

    uint32_t pwmClock = gSysClk / 64;
    uint32_t period = pwmClock / freq_hz;

    PWMGenConfigure(BUZZER_PWM_BASE, BUZZER_GEN, PWM_GEN_MODE_DOWN);
    PWMGenPeriodSet(BUZZER_PWM_BASE, BUZZER_GEN, period);
    PWMPulseWidthSet(BUZZER_PWM_BASE, BUZZER_OUTNUM, period / 2);
    PWMOutputState(BUZZER_PWM_BASE, BUZZER_OUTBIT, true);
    PWMGenEnable(BUZZER_PWM_BASE, BUZZER_GEN);
}

static void BuzzerBeepOff(){
    PWMOutputState(BUZZER_PWM_BASE, BUZZER_OUTBIT, false);
}
