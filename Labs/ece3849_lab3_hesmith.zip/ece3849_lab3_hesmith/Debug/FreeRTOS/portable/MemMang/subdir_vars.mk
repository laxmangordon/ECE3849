################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
C:/Users/harle/Documents/ECE3849Lab1/ECE3849Lab1/FreeRTOS/portable/MemMang/heap_4.c 

C_DEPS += \
./FreeRTOS/portable/MemMang/heap_4.d 

OBJS += \
./FreeRTOS/portable/MemMang/heap_4.obj 

OBJS__QUOTED += \
"FreeRTOS\portable\MemMang\heap_4.obj" 

C_DEPS__QUOTED += \
"FreeRTOS\portable\MemMang\heap_4.d" 

C_SRCS__QUOTED += \
"C:/Users/harle/Documents/ECE3849Lab1/ECE3849Lab1/FreeRTOS/portable/MemMang/heap_4.c" 


