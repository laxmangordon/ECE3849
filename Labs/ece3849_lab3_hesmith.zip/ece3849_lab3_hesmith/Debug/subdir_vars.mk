################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
C:/Users/harle/Downloads/snake_base_lab3/snake_base_lab3/display.cpp \
C:/Users/harle/Downloads/snake_base_lab3/snake_base_lab3/game.cpp \
C:/Users/harle/Downloads/snake_base_lab3/snake_base_lab3/main.cpp 

CMD_SRCS += \
../tm4c1294ncpdt.cmd 

C_SRCS += \
../startup_ccs.c 

C_DEPS += \
./startup_ccs.d 

OBJS += \
./display.obj \
./game.obj \
./main.obj \
./startup_ccs.obj 

CPP_DEPS += \
./display.d \
./game.d \
./main.d 

OBJS__QUOTED += \
"display.obj" \
"game.obj" \
"main.obj" \
"startup_ccs.obj" 

C_DEPS__QUOTED += \
"startup_ccs.d" 

CPP_DEPS__QUOTED += \
"display.d" \
"game.d" \
"main.d" 

CPP_SRCS__QUOTED += \
"C:/Users/harle/Downloads/snake_base_lab3/snake_base_lab3/display.cpp" \
"C:/Users/harle/Downloads/snake_base_lab3/snake_base_lab3/game.cpp" \
"C:/Users/harle/Downloads/snake_base_lab3/snake_base_lab3/main.cpp" 

C_SRCS__QUOTED += \
"../startup_ccs.c" 


